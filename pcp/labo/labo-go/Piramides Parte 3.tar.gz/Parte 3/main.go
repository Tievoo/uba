package main

import (
	"fmt"
	"sync"
)

type Asociado struct {
	nombre string
	yuanes int
}

func NuevoAsociado(nombre string) *Asociado {
	return &Asociado{
		nombre: nombre,
		yuanes: 1000,
	}
}

func main() {
	canalNombres := make(chan string)
	go Nombres(canalNombres)
	var wg sync.WaitGroup
	wg.Add(1)
	raiz := NuevoAsociado("Hernán")
	go raiz.unirseGeneración(canalNombres, &wg)
	wg.Wait()
}

// Hasta acá está resuelta la generación de la pirámide (partes I y II).
func (A *Asociado) unirseGeneración(canalNombres chan string, wg *sync.WaitGroup) {
	defer wg.Done()
	A.invitar(canalNombres, wg)
}

func (A *Asociado) invitar(canalNombres chan string, wg *sync.WaitGroup) {
	// Hacer hasta 4 asociados.
	for numAsociado := 0; numAsociado < 4; numAsociado++ {
		nombreAsociado, ok := <-canalNombres
		if !ok {
			return
		}
		fmt.Println("Asociado: ", nombreAsociado, " con jefe: ", A.nombre)
		asociado := NuevoAsociado(nombreAsociado)
		wg.Add(1)
		go asociado.unirseGeneración(canalNombres, wg)
	}
}
