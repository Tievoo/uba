package main

import (
	"fmt"
	"sync"
	"time"
)

type Pago struct {
	monto        int
	nombreOrigen string
}

type Asociado struct {
	nombre            string
	yuanes            int
	pagosJefe         chan<- Pago   // Canal para enviar pagos al jefe
	pagosAsociados    <-chan Pago   // Canal para recibir pagos de los asociados
	nombresAsociados  [4]string     // Nombres de los asociados
	// TODO Parte IV: agregar los canales para recibir y repartir comisiones.
}

func NuevoAsociado(nombre string, pagosJefe chan<- Pago) *Asociado {
	return &Asociado{
		nombre:            nombre,
		yuanes:            1000,
		pagosJefe:         pagosJefe,
		nombresAsociados:  [4]string{""},
	}
}

func main() {
	canalNombres := make(chan string)
	go Nombres(canalNombres)
	var wg sync.WaitGroup
	wg.Add(1)
	raiz := NuevoAsociado("Hernán", nil)
	go raiz.unirseGeneración(canalNombres, &wg)
	wg.Wait()
}

func (A *Asociado) nSubordinados() int {
	count := 0
	for _, nombre := range A.nombresAsociados {
		if nombre != "" {
			count++
		}
	}
	return count
}

func (A *Asociado) indiceAsociado(nombre string) int {
	for i, n := range A.nombresAsociados {
		if n == nombre {
			return i
		}
	}
	return -1 // Not found
}

func (A *Asociado) enviarComisionesSubordinados(monto int) {
	// TODO Parte IV: repartir el monto en partes iguales entre los subordinados.
}

func (A *Asociado) unirseGeneración(canalNombres chan string, wg *sync.WaitGroup) {
	defer wg.Done()
	A.invitar(canalNombres, wg)
	ticker := time.NewTicker(100 * time.Millisecond)
	defer ticker.Stop()
	for {
		if A.nSubordinados() == 0 {
			// Si soy el jefe, imprimo mi total de yuanes y salgo
			if A.pagosJefe == nil {
				fmt.Printf("Asociado %s terminó con %d yuanes\n", A.nombre, A.yuanes)
				return
			}
			// Solo pago 100 yuanes en cada intervalo de tiempo, si no tengo asociados a los que pagarles comisiones
			select {
			case <-ticker.C:
				pago := Pago{
					monto:        100,
					nombreOrigen: A.nombre,
				}
				A.yuanes -= pago.monto
				// Si yuanes negativos, no puedo pagarle al jefe. Mando 0 y salgo
				if A.yuanes < 0 {
					pago.monto = 0
					A.pagosJefe <- pago
					return
				}
				A.pagosJefe <- pago
			// TODO Parte IV: esperar y procesar una comisión del jefe.
			}
		} else {
			// Si tengo asociados, recibo pagos de ellos y reenvio al jefe. Salvo que sea jefe. Que me quede el 50% de la comisión y le pase el resto a los asociados
			select {
			case pago := <-A.pagosAsociados:
				// Si recibo pago 0, quiere decir que el asociado termino
				if pago.monto == 0 {
					// Encontrar el índice del asociado que me está pagando
					indice := A.indiceAsociado(pago.nombreOrigen)
					if indice >= 0 {
						A.nombresAsociados[indice] = ""
					}
				} else {
					// Reenviar el pago al jefe si tengo un jefe; si soy el jefe principal, me lo quedo.
					if A.pagosJefe == nil {
						A.yuanes += pago.monto
					} else {
						A.pagosJefe <- pago
					}
				}
			// TODO Parte IV: esperar y procesar una comisión del jefe.
			}
		}
	}
}

func (A *Asociado) invitar(canalNombres chan string, wg *sync.WaitGroup) {
	// Hacer hasta 4 asociados
	pagos := make(chan Pago, 4)
	A.pagosAsociados = pagos
	for numAsociado := 0; numAsociado < 4; numAsociado++ {
		nombreAsociado, ok := <-canalNombres
		if !ok {
			return
		}
		A.nombresAsociados[numAsociado] = nombreAsociado
		fmt.Println("Asociado: ", nombreAsociado, " con jefe: ", A.nombre)
		asociado := NuevoAsociado(nombreAsociado, pagos)
		wg.Add(1)
		go asociado.unirseGeneración(canalNombres, wg)
	}
}
